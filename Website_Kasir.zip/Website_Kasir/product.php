<div class="col-lg-9 mt-2">
    <div class="card">
        <div class="card-header">
            Product
        </div>
        <div class="card-body">
            <h5 class="card-title">Ini bagian Product</h5>
            <p class="card-text">With supporting text below as a natural lead-in to additional content.
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit eaque aliquam ipsa,
                repellat quo quam facere iure id esse aperiam!</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
    </div>
</div>