<?php
    $conn =mysqli_connect("localhost","root","","db_kasir");
    if(!$conn){
        echo "gagal connect";
    }
?>